<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'pofilmoi_art');
define('DB_USER', 'pofilmoi_artuser');
define('DB_PASS', 'Nooshin@@1367');

define('SITE_NAME', 'نوش آرت');
define('ADMIN_EMAIL', 'info@artnooshin.ir');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', 'uploads/');

// SMTP اختیاری برای PHPMailer
define('SMTP_HOST', '');
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');

date_default_timezone_set('Asia/Tehran');